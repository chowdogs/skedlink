export const mockSchedules = {}
