export const mockDormitories = []
