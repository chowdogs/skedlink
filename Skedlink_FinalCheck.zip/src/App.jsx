import React, { useState } from 'react'
import { Landing } from './views/pages/Landing'
import { Login } from './views/pages/Login'
import { Register } from './views/pages/Register'
import { SeekerDashboard } from './views/pages/SeekerDashboard'
import { OwnerDashboard } from './views/pages/OwnerDashboard'
import { MainLayout } from './views/layouts/MainLayout'
import { AuthProvider, useAuth } from './contexts/AuthContext'

function AppRoutes() {
  const { logout } = useAuth()
  const [page, setPage] = useState('register')
  const [currentUser, setCurrentUser] = useState(null)

  const handleLogin = (profile) => {
    setCurrentUser(profile)
    setPage(profile.role === 'seeker' ? 'seeker-dashboard' : 'owner-dashboard')
  }

  const handleLogout = async () => {
    await logout()
    setCurrentUser(null)
    setPage('register')
  }

  return (
    <>
      {page === 'landing' && (
        <MainLayout onLogout={handleLogout}>
          <Landing onGetStarted={() => setPage('register')} />
        </MainLayout>
      )}

      {page === 'login' && (
        <Login onLogin={handleLogin} onGoToRegister={() => setPage('register')} />
      )}

      {page === 'register' && (
        <Register onRegister={handleLogin} onGoToLogin={() => setPage('login')} />
      )}

      {page === 'seeker-dashboard' && currentUser && (
        <MainLayout onLogout={handleLogout} currentUser={currentUser}>
          <SeekerDashboard user={currentUser} />
        </MainLayout>
      )}

      {page === 'owner-dashboard' && currentUser && (
        <MainLayout onLogout={handleLogout} currentUser={currentUser}>
          <OwnerDashboard user={currentUser} />
        </MainLayout>
      )}
    </>
  )
}

function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  )
}

export default App
