import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card'
import { Input, Label } from '../ui/Input'
import { Button } from '../ui/Button'
import { useAuth } from '../../contexts/AuthContext'

export const Register = ({ onRegister, onGoToLogin }) => {
  const { register } = useAuth()
  const [role, setRole] = useState('seeker')
  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (password !== confirmPassword) {
      setError('Passwords do not match.')
      return
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.')
      return
    }

    setLoading(true)
    try {
      const profile = await register(email, password, fullName, role, phone)
      onRegister(profile)
    } catch (err) {
      setError(err.message.replace('Firebase: ', '').replace(/\(auth\/.*\)\.?/, '').trim())
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className='min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center px-4 py-8'>
      <div className='w-full max-w-md'>
        {/* Logo */}
        <div className='text-center mb-8'>
          <div className='w-16 h-16 bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-2xl flex items-center justify-center mx-auto mb-4'>
            <span className='text-white font-bold text-2xl'>S</span>
          </div>
          <h1 className='text-3xl font-bold text-slate-900'>SkedLink</h1>
          <p className='text-slate-600 mt-2'>Create your account</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Create Account</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className='space-y-4'>
              {/* Role Toggle */}
              <div>
                <Label>I am a</Label>
                <div className='flex gap-2 mt-1'>
                  <button
                    type='button'
                    onClick={() => setRole('seeker')}
                    className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                      role === 'seeker'
                        ? 'bg-indigo-600 text-white shadow-md'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    Tenant
                  </button>
                  <button
                    type='button'
                    onClick={() => setRole('owner')}
                    className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
                      role === 'owner'
                        ? 'bg-indigo-600 text-white shadow-md'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    Landlord
                  </button>
                </div>
              </div>

              <div>
                <Label htmlFor='fullName'>Full Name</Label>
                <Input
                  id='fullName'
                  placeholder='Juan dela Cruz'
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor='email'>Email</Label>
                <Input
                  id='email'
                  type='email'
                  placeholder='you@email.com'
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor='phone'>Phone Number</Label>
                <Input
                  id='phone'
                  type='tel'
                  placeholder='+63 917 123 4567'
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor='password'>Password</Label>
                <Input
                  id='password'
                  type='password'
                  placeholder='At least 6 characters'
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor='confirmPassword'>Re-enter Password</Label>
                <Input
                  id='confirmPassword'
                  type='password'
                  placeholder='Repeat your password'
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>

              {error && (
                <p className='text-sm text-red-600 bg-red-50 border border-red-200 p-3 rounded-lg'>
                  {error}
                </p>
              )}

              <Button type='submit' variant='primary' className='w-full' disabled={loading}>
                {loading ? 'Creating account...' : 'Create Account'}
              </Button>
            </form>

            <div className='mt-4 pt-4 border-t border-slate-200 text-center'>
              <span className='text-sm text-slate-600'>Already have an account? </span>
              <button
                onClick={onGoToLogin}
                className='text-sm text-indigo-600 hover:text-indigo-700 font-medium'
              >
                Sign in here
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
