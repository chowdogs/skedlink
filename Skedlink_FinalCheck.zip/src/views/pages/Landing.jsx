import React from 'react'
import { Button } from '../ui/Button'
import { Card, CardContent } from '../ui/Card'

export const Landing = ({ onGetStarted }) => {
  return (
    <div className='bg-gradient-to-br from-slate-50 via-indigo-50 to-slate-100 min-h-screen'>
      {/* Hero Section */}
      <section className='max-w-6xl mx-auto px-6 py-20'>
        <div className='text-center space-y-6 mb-16'>
          <h1 className='text-5xl md:text-6xl font-bold text-slate-900 leading-tight'>
            Match Roommates by <span className='text-indigo-600'>Lifestyle</span>
          </h1>
          <p className='text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed'>
            Stop clashing schedules. Start living harmoniously. SkedLink matches you with roommates based on real compatibility, not just price.
          </p>
          <Button onClick={onGetStarted} size='lg' className='mx-auto'>
            Get Started Free
          </Button>
        </div>

        <div className='relative rounded-2xl overflow-hidden shadow-2xl bg-white p-8'>
          <div className='aspect-video bg-gradient-to-br from-indigo-100 to-emerald-100 rounded-xl flex items-center justify-center'>
            <div className='text-center'>
              <div className='inline-block p-4 bg-white rounded-xl mb-4'>
                <svg className='w-16 h-16 text-indigo-600' fill='currentColor' viewBox='0 0 24 24'>
                  <path d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z' />
                </svg>
              </div>
              <p className='text-slate-600 font-medium'>24-Hour Schedule Matching</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className='max-w-6xl mx-auto px-6 py-20'>
        <h2 className='text-3xl font-bold text-slate-900 text-center mb-12'>Why SkedLink?</h2>
        
        <div className='grid grid-cols-1 md:grid-cols-3 gap-6'>
          <Card>
            <CardContent>
              <div className='w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4'>
                <span className='text-2xl'>⏰</span>
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Smart Scheduling</h3>
              <p className='text-slate-600 text-sm'>
                Visualize your 24-hour cycle. Mark sleep, study, work, and break times to find perfect matches.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className='w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4'>
                <span className='text-2xl'>🤝</span>
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Compatibility Scoring</h3>
              <p className='text-slate-600 text-sm'>
                Our algorithm calculates real compatibility based on overlapping quiet hours and lifestyle preferences.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className='w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-4'>
                <span className='text-2xl'>🏠</span>
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Harmony Marketplace</h3>
              <p className='text-slate-600 text-sm'>
                Browse rooms and see compatibility with current tenants. No more surprise conflicts.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className='w-12 h-12 bg-rose-100 rounded-lg flex items-center justify-center mb-4'>
                <span className='text-2xl'>✅</span>
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Chore Management</h3>
              <p className='text-slate-600 text-sm'>
                Assign and track household tasks without complex billing. Keep harmony, not spreadsheets.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className='w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center mb-4'>
                <span className='text-2xl'>📊</span>
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Real-Time Matching</h3>
              <p className='text-slate-600 text-sm'>
                Get instant match percentages. Know your compatibility before signing the lease.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className='w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4'>
                <span className='text-2xl'>🎓</span>
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Student-First Design</h3>
              <p className='text-slate-600 text-sm'>
                Built by students, for students. Understanding real dorm life challenges.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className='bg-gradient-to-r from-indigo-600 to-indigo-700 py-16 mt-20'>
        <div className='max-w-4xl mx-auto px-6 text-center text-white space-y-4'>
          <h2 className='text-3xl font-bold'>Ready to Find Your Perfect Roommate?</h2>
          <p className='text-indigo-100 text-lg'>Join students already living in harmony</p>
          <Button onClick={onGetStarted} variant='secondary' size='lg' className='mx-auto'>
            Start Matching Now
          </Button>
        </div>
      </section>
    </div>
  )
}
