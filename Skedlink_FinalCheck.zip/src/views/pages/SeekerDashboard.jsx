import React, { useState, useEffect } from 'react'
import { collection, query, where, onSnapshot } from 'firebase/firestore'
import { db } from '../../firebase'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card'
import { Button } from '../ui/Button'
import { Badge } from '../ui/Badge'
import { Input, Label } from '../ui/Input'
import { SchedulePainter } from '../components/schedule/SchedulePainter'
import { PropertyMap } from '../components/map/PropertyMap'
import { ContactModal } from '../components/property/ContactModal'
import { ChatModal } from '../components/property/ChatModal'
import { useSchedulePainter } from '../../controllers/useSchedulePainter'
import { useCompatibility } from '../../controllers/useCompatibility'
import { useChoreManager } from '../../controllers/useChoreManager'
import { useAuth } from '../../contexts/AuthContext'
import { compressToBase64 } from '../../lib/compressToBase64'

const OCCUPATIONS = [
  'Studying', 'Working', 'Studying & Working',
  'Business Owner', 'Freelancer', 'Remote Worker', 'Other'
]

const getScoreColor = (score) => {
  if (score >= 80) return 'success'
  if (score >= 60) return 'primary'
  if (score >= 40) return 'warning'
  return 'danger'
}

export const SeekerDashboard = ({ user }) => {
  const { updateUserProfile, changePassword, logout } = useAuth()
  const [activeTab, setActiveTab] = useState('overview')
  const [saveMsg, setSaveMsg] = useState('')
  const [locationFilter, setLocationFilter] = useState('')
  const [contactProperty, setContactProperty] = useState(null)
  const [activeInquiry, setActiveInquiry] = useState(null)
  const [myInquiries, setMyInquiries] = useState([])

  const schedulePainter = useSchedulePainter(user.uid)
  const liveProfile = { ...user, weeklySchedule: schedulePainter.schedule }
  const compatibility = useCompatibility(liveProfile)
  const choreManager = useChoreManager()

  const displayName = user.fullName || user.name || 'Tenant'

  // Load this tenant's own inquiries (real-time)
  useEffect(() => {
    const q = query(collection(db, 'inquiries'), where('tenantUid', '==', user.uid))
    return onSnapshot(q, snap => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() }))
      setMyInquiries(list)
      // Keep activeInquiry in sync if it's open
      setActiveInquiry(prev => {
        if (!prev) return prev
        const updated = list.find(i => i.id === prev.id)
        return updated || prev
      })
    })
  }, [user.uid])

  // Profile state
  const [profilePhoto, setProfilePhoto] = useState(user.profilePhoto || '')
  const [profileName, setProfileName] = useState(user.fullName || '')
  const [gender, setGender] = useState(user.gender || '')
  const [age, setAge] = useState(user.age || '')
  const [occupation, setOccupation] = useState(user.occupation || '')
  const [bio, setBio] = useState(user.bio || '')
  const [validIdUrl, setValidIdUrl] = useState(user.validIdUrl || '')
  const [profileSaving, setProfileSaving] = useState(false)
  const [profileMsg, setProfileMsg] = useState('')
  const [photoUploading, setPhotoUploading] = useState(false)
  const [idUploading, setIdUploading] = useState(false)
  const [pwCurrent, setPwCurrent] = useState('')
  const [pwNew, setPwNew] = useState('')
  const [pwConfirm, setPwConfirm] = useState('')
  const [pwMsg, setPwMsg] = useState('')

  const handleSaveSchedule = async () => {
    try {
      await schedulePainter.saveSchedule()
      setSaveMsg('Schedule saved!')
      setTimeout(() => setSaveMsg(''), 3000)
    } catch {
      setSaveMsg('Failed to save. Try again.')
      setTimeout(() => setSaveMsg(''), 3000)
    }
  }

  const handleProfilePhotoUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setPhotoUploading(true)
    try {
      const b64 = await compressToBase64(file, { maxPx: 400, quality: 0.8 })
      setProfilePhoto(b64)
      await updateUserProfile({ profilePhoto: b64 })
    } catch (err) {
      setProfileMsg('Photo upload failed: ' + err.message)
    } finally {
      setPhotoUploading(false)
    }
  }

  const handleValidIdUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setIdUploading(true)
    try {
      const b64 = await compressToBase64(file, { maxPx: 1200, quality: 0.82 })
      setValidIdUrl(b64)
      await updateUserProfile({ validIdUrl: b64 })
      setProfileMsg('Valid ID uploaded!')
      setTimeout(() => setProfileMsg(''), 3000)
    } catch (err) {
      setProfileMsg('ID upload failed: ' + err.message)
    } finally {
      setIdUploading(false)
    }
  }

  const handleSaveProfile = async () => {
    setProfileSaving(true)
    setProfileMsg('')
    try {
      await updateUserProfile({
        fullName: profileName,
        gender,
        age: age ? Number(age) : '',
        occupation,
        bio
      })
      setProfileMsg('Profile updated!')
      setTimeout(() => setProfileMsg(''), 3000)
    } catch (err) {
      setProfileMsg('Error: ' + err.message)
    } finally {
      setProfileSaving(false)
    }
  }

  const handleChangePassword = async () => {
    setPwMsg('')
    if (pwNew !== pwConfirm) { setPwMsg('New passwords do not match.'); return }
    if (pwNew.length < 6) { setPwMsg('Password must be at least 6 characters.'); return }
    try {
      await changePassword(pwCurrent, pwNew)
      setPwMsg('Password changed!')
      setPwCurrent(''); setPwNew(''); setPwConfirm('')
      setTimeout(() => setPwMsg(''), 4000)
    } catch (err) {
      setPwMsg('Error: ' + err.message.replace('Firebase: ', '').replace(/\(auth\/.*\)\.?/, '').trim())
    }
  }

  const TABS = [
    { id: 'overview', label: 'Overview' },
    { id: 'schedule', label: 'My Schedule' },
    { id: 'matching', label: 'Property Matches' },
    { id: 'profile', label: 'My Profile' }
  ]

  const filteredProperties = compatibility.results.filter(p =>
    !locationFilter ||
    (p.location?.address || '').toLowerCase().includes(locationFilter.toLowerCase())
  )

  return (
    <div className='max-w-7xl mx-auto px-6 py-8'>
      <div className='mb-8'>
        <h1 className='text-4xl font-bold text-slate-900'>Welcome, {displayName}!</h1>
        <p className='text-slate-600 mt-2'>{user.occupation || 'Tenant'}</p>
      </div>

      {/* Tabs */}
      <div className='flex gap-2 mb-8 border-b border-slate-200 overflow-x-auto'>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-3 font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === tab.id ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── OVERVIEW ── */}
      {activeTab === 'overview' && (
        <div className='space-y-6'>
          <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
            <Card><CardContent><div className='text-center'>
              <div className='text-3xl font-bold text-indigo-600 mb-1'>{compatibility.results.length}</div>
              <p className='text-slate-600 text-sm'>Properties Found</p>
            </div></CardContent></Card>
            <Card><CardContent><div className='text-center'>
              <div className='text-3xl font-bold text-emerald-600 mb-1'>{compatibility.results[0]?.score ?? 0}%</div>
              <p className='text-slate-600 text-sm'>Best Match</p>
            </div></CardContent></Card>
            <Card><CardContent><div className='text-center'>
              <div className='text-3xl font-bold text-amber-600 mb-1'>{myInquiries.length}</div>
              <p className='text-slate-600 text-sm'>Inquiries Sent</p>
            </div></CardContent></Card>
            <Card><CardContent><div className='text-center'>
              <div className='text-3xl font-bold text-slate-600 mb-1'>{user.occupation || '—'}</div>
              <p className='text-slate-600 text-sm'>Occupation</p>
            </div></CardContent></Card>
          </div>

          {/* My active inquiries */}
          {myInquiries.length > 0 && (
            <Card>
              <CardHeader><CardTitle>My Inquiries</CardTitle></CardHeader>
              <CardContent>
                <div className='space-y-3'>
                  {myInquiries.map(inq => (
                    <div key={inq.id}
                      className='flex items-center justify-between gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100'>
                      <div className='min-w-0'>
                        <p className='font-medium text-slate-900 text-sm truncate'>{inq.propertyTitle}</p>
                        <p className='text-xs text-slate-500 capitalize'>
                          {inq.type === 'rent' ? 'Wants to rent' : 'Wants to visit'}
                        </p>
                      </div>
                      <div className='flex items-center gap-2 shrink-0'>
                        <Badge variant={inq.status === 'active' ? 'success' : 'warning'}>{inq.status}</Badge>
                        {inq.unreadByTenant && (
                          <span className='w-2 h-2 rounded-full bg-indigo-600' title='New reply' />
                        )}
                        <button
                          type='button'
                          onClick={() => setActiveInquiry(inq)}
                          className='text-sm text-indigo-600 font-medium hover:text-indigo-800'
                        >
                          Open →
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* ── SCHEDULE ── */}
      {activeTab === 'schedule' && (
        <div className='bg-white rounded-xl p-8 shadow-sm border border-slate-200'>
          {!schedulePainter.loaded ? (
            <p className='text-slate-500'>Loading your schedule...</p>
          ) : (
            <>
              <SchedulePainter
                schedule={schedulePainter.schedule}
                onHourChange={schedulePainter.updateHour}
                currentActivity={schedulePainter.currentActivity}
                onActivityChange={schedulePainter.setCurrentActivity}
                allActivities={schedulePainter.allActivities}
                getActivityHex={schedulePainter.getActivityHex}
                customActivities={schedulePainter.customActivities}
                onAddCustomActivity={schedulePainter.addCustomActivity}
                onRemoveCustomActivity={schedulePainter.removeCustomActivity}
              />
              <div className='mt-6 flex items-center gap-3'>
                <Button onClick={schedulePainter.reset} variant='secondary'>Reset</Button>
                <Button onClick={handleSaveSchedule} variant='primary' disabled={schedulePainter.saving}>
                  {schedulePainter.saving ? 'Saving...' : 'Save Schedule'}
                </Button>
                {saveMsg && <span className='text-sm text-emerald-600 font-medium'>{saveMsg}</span>}
              </div>
            </>
          )}
        </div>
      )}

      {/* ── MATCHING ── */}
      {activeTab === 'matching' && (
        <div className='space-y-6'>
          <div className='p-4 bg-indigo-50 border border-indigo-200 rounded-lg'>
            <p className='text-sm text-indigo-900'>
              Compatibility compares your quiet hours (sleep + at school) against existing tenants.
              Properties with 0 tenants show 100%. Save your schedule first for accurate results.
            </p>
          </div>

          {compatibility.loading ? (
            <div className='text-center py-12 text-slate-500'>Loading properties...</div>
          ) : (
            <>
              <input
                type='text'
                value={locationFilter}
                onChange={(e) => setLocationFilter(e.target.value)}
                placeholder='Filter by location (e.g. Baliwag, Manila)...'
                className='w-full px-4 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500'
              />

              <Card>
                <CardHeader><CardTitle>Properties on Map</CardTitle></CardHeader>
                <CardContent>
                  <PropertyMap properties={filteredProperties} />
                </CardContent>
              </Card>

              {filteredProperties.length === 0 ? (
                <Card><CardContent>
                  <div className='text-center py-12'>
                    <p className='text-lg text-slate-600'>No properties found.</p>
                  </div>
                </CardContent></Card>
              ) : (
                <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
                  {filteredProperties.map(property => {
                    const existingInquiry = myInquiries.find(i => i.propertyId === property.id)
                    return (
                      <Card key={property.id} className='hover:shadow-lg transition-shadow'>
                        <CardContent>
                          {property.photos?.[0] && (
                            <img src={property.photos[0]} alt={property.title}
                              className='w-full h-36 object-cover rounded-lg mb-4'
                              onError={e => { e.target.style.display = 'none' }} />
                          )}
                          <div className='flex items-start justify-between mb-2'>
                            <div>
                              <h3 className='font-semibold text-slate-900 text-lg'>{property.title}</h3>
                              <p className='text-xs text-slate-500'>{property.location?.address || 'No location'}</p>
                            </div>
                            <div className='text-right'>
                              <Badge variant={getScoreColor(property.score)} className='text-base font-bold px-3 py-1'>
                                {property.score}%
                              </Badge>
                              <p className='text-xs text-slate-500 mt-1'>Match</p>
                            </div>
                          </div>

                          {property.description && (
                            <p className='text-sm text-slate-600 mb-3 line-clamp-2'>{property.description}</p>
                          )}

                          <div className='grid grid-cols-3 gap-2 text-sm mb-4'>
                            <div>
                              <span className='text-slate-400 text-xs'>Price</span>
                              <p className='font-medium'>₱{Number(property.price).toLocaleString()}/mo</p>
                            </div>
                            <div>
                              <span className='text-slate-400 text-xs'>Tenants</span>
                              <p className='font-medium'>{property.tenants?.length || 0}/{property.capacity}</p>
                            </div>
                            <div>
                              <span className='text-slate-400 text-xs'>Curfew</span>
                              <p className='font-medium'>{property.rules?.curfew || 'No Curfew'}</p>
                            </div>
                          </div>

                          {property.rules?.genderRestriction && property.rules.genderRestriction !== 'none' && (
                            <Badge variant='slate' className='text-xs capitalize mb-3'>
                              {property.rules.genderRestriction} only
                            </Badge>
                          )}

                          {existingInquiry ? (
                            <div className='space-y-2'>
                              <div className='flex items-center gap-2 px-3 py-2 bg-emerald-50 rounded-lg border border-emerald-200'>
                                <svg className='w-4 h-4 text-emerald-600 shrink-0' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                  <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M5 13l4 4L19 7' />
                                </svg>
                                <span className='text-sm text-emerald-700 font-medium flex-1'>Inquiry Sent</span>
                                <Badge variant={existingInquiry.status === 'active' ? 'success' : 'warning'} className='text-xs'>
                                  {existingInquiry.status}
                                </Badge>
                                {existingInquiry.unreadByTenant && (
                                  <span className='w-2 h-2 rounded-full bg-indigo-600 shrink-0' title='New reply' />
                                )}
                              </div>
                              <Button
                                variant='secondary'
                                size='sm'
                                className='w-full'
                                onClick={() => setActiveInquiry(existingInquiry)}
                              >
                                Open Chat
                              </Button>
                            </div>
                          ) : (
                            <Button
                              variant='primary'
                              size='sm'
                              className='w-full'
                              onClick={() => setContactProperty(property)}
                            >
                              Contact Landlord
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* ── PROFILE ── */}
      {activeTab === 'profile' && (
        <div className='max-w-xl space-y-6'>
          <Card>
            <CardHeader><CardTitle>Profile Photo</CardTitle></CardHeader>
            <CardContent>
              <div className='flex items-center gap-6'>
                <div className='w-20 h-20 rounded-full overflow-hidden bg-indigo-100 border-2 border-indigo-200 shrink-0'>
                  {profilePhoto
                    ? <img src={profilePhoto} alt='Profile' className='w-full h-full object-cover' />
                    : <div className='w-full h-full flex items-center justify-center text-2xl font-bold text-indigo-600'>
                        {displayName.charAt(0).toUpperCase()}
                      </div>
                  }
                </div>
                <div>
                  <label className='cursor-pointer'>
                    <span className='px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors'>
                      {photoUploading ? 'Uploading...' : 'Upload Photo'}
                    </span>
                    <input type='file' accept='image/*' className='hidden' onChange={handleProfilePhotoUpload} disabled={photoUploading} />
                  </label>
                  <p className='text-xs text-slate-500 mt-2'>JPG, PNG — max 5 MB</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Personal Information</CardTitle></CardHeader>
            <CardContent className='space-y-4'>
              <div>
                <Label>Full Name</Label>
                <Input value={profileName} onChange={e => setProfileName(e.target.value)} />
              </div>
              <div>
                <Label>Email</Label>
                <Input value={user.email} disabled className='opacity-60 cursor-not-allowed' />
              </div>

              <div>
                <Label>Gender</Label>
                <div className='flex gap-2 mt-1'>
                  {['Male', 'Female'].map(g => (
                    <button
                      key={g}
                      type='button'
                      onClick={() => setGender(g.toLowerCase())}
                      className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all border ${
                        gender === g.toLowerCase()
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-white text-slate-700 border-slate-300 hover:border-indigo-300'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Age</Label>
                <Input type='number' min='16' max='100' value={age} onChange={e => setAge(e.target.value)} placeholder='e.g. 22' />
              </div>

              <div>
                <Label>Occupation</Label>
                <select
                  value={occupation}
                  onChange={e => setOccupation(e.target.value)}
                  className='w-full mt-1 px-4 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500'
                >
                  <option value=''>Select occupation...</option>
                  {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>

              <div>
                <Label>About Me</Label>
                <textarea
                  value={bio}
                  onChange={e => setBio(e.target.value)}
                  rows={3}
                  placeholder='Tell landlords a bit about yourself...'
                  className='w-full mt-1 px-4 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none'
                />
              </div>

              {profileMsg && (
                <p className={`text-sm ${profileMsg.toLowerCase().includes('fail') || profileMsg.toLowerCase().includes('error') ? 'text-red-600' : 'text-emerald-600'}`}>
                  {profileMsg}
                </p>
              )}
              <Button onClick={handleSaveProfile} variant='primary' disabled={profileSaving}>
                {profileSaving ? 'Saving...' : 'Save Profile'}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Valid ID</CardTitle></CardHeader>
            <CardContent className='space-y-3'>
              <p className='text-sm text-slate-600'>
                Upload a government-issued ID for identity verification. Landlords may request this before approving your application.
              </p>
              {validIdUrl && (
                <div className='rounded-lg overflow-hidden border border-slate-200'>
                  <img src={validIdUrl} alt='Valid ID' className='w-full object-cover max-h-48' />
                </div>
              )}
              <label className='cursor-pointer block'>
                <span className={`inline-flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors ${idUploading ? 'bg-slate-200 text-slate-500 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}>
                  {idUploading ? 'Uploading...' : validIdUrl ? 'Replace ID' : 'Upload Valid ID'}
                </span>
                <input type='file' accept='image/*,.pdf' className='hidden' onChange={handleValidIdUpload} disabled={idUploading} />
              </label>
              <p className='text-xs text-slate-400'>Accepted: JPG, PNG, PDF</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Change Password</CardTitle></CardHeader>
            <CardContent className='space-y-3'>
              <div>
                <Label>Current Password</Label>
                <Input type='password' value={pwCurrent} onChange={e => setPwCurrent(e.target.value)} placeholder='Enter current password' />
              </div>
              <div>
                <Label>New Password</Label>
                <Input type='password' value={pwNew} onChange={e => setPwNew(e.target.value)} placeholder='At least 6 characters' />
              </div>
              <div>
                <Label>Confirm New Password</Label>
                <Input type='password' value={pwConfirm} onChange={e => setPwConfirm(e.target.value)} placeholder='Repeat new password' />
              </div>
              {pwMsg && <p className={`text-sm ${pwMsg.startsWith('Error') ? 'text-red-600' : 'text-emerald-600'}`}>{pwMsg}</p>}
              <Button onClick={handleChangePassword} variant='primary'>Update Password</Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <Button onClick={logout} variant='danger' className='w-full'>Sign Out</Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modals */}
      {contactProperty && (
        <ContactModal
          property={contactProperty}
          tenant={user}
          onSent={(inquiry) => {
            setContactProperty(null)
            setActiveInquiry(inquiry)
          }}
          onClose={() => setContactProperty(null)}
        />
      )}
      {activeInquiry && (
        <ChatModal
          inquiry={activeInquiry}
          currentUser={user}
          onClose={() => setActiveInquiry(null)}
        />
      )}
    </div>
  )
}
