import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card'
import { Button } from '../ui/Button'
import { Badge } from '../ui/Badge'
import { Input, Label } from '../ui/Input'
import { LocationPicker } from '../components/map/LocationPicker'
import { ImageUploader } from '../components/map/ImageUploader'
import { EditPropertyModal } from '../components/property/EditPropertyModal'
import { ChatModal } from '../components/property/ChatModal'
import {
  collection, query, where, onSnapshot,
  addDoc, deleteDoc, doc, serverTimestamp, orderBy
} from 'firebase/firestore'
import { ref } from 'firebase/storage'
import { db, storage } from '../../firebase'
import { useAuth } from '../../contexts/AuthContext'
import { uploadFile } from '../../lib/uploadFile'

const EMPTY_FORM = {
  title: '', description: '', price: '', capacity: '',
  curfewEnabled: false, curfew: '',
  genderRestriction: 'none', photos: [], location: null
}

// Toggle switch component
const Toggle = ({ on, onToggle, labelOn, labelOff }) => (
  <div className='flex items-center gap-3'>
    <button
      type='button'
      onClick={onToggle}
      className={`relative w-10 h-5 rounded-full transition-colors ${on ? 'bg-indigo-600' : 'bg-slate-300'}`}
    >
      <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${on ? 'translate-x-5' : 'translate-x-0.5'}`} />
    </button>
    <span className='text-sm text-slate-600'>{on ? labelOn : labelOff}</span>
  </div>
)

export const OwnerDashboard = ({ user }) => {
  const { updateUserProfile, changePassword, logout } = useAuth()
  const [activeTab, setActiveTab] = useState('overview')
  const [properties, setProperties] = useState([])
  const [inquiries, setInquiries] = useState([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingProperty, setEditingProperty] = useState(null)
  const [chatInquiry, setChatInquiry] = useState(null)
  const [formData, setFormData] = useState(EMPTY_FORM)
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState('')

  // Profile state
  const [profilePhoto, setProfilePhoto] = useState(user.profilePhoto || '')
  const [profileName, setProfileName] = useState(user.fullName || '')
  const [profileSaving, setProfileSaving] = useState(false)
  const [profileMsg, setProfileMsg] = useState('')
  const [pwCurrent, setPwCurrent] = useState('')
  const [pwNew, setPwNew] = useState('')
  const [pwConfirm, setPwConfirm] = useState('')
  const [pwMsg, setPwMsg] = useState('')
  const [photoUploading, setPhotoUploading] = useState(false)

  useEffect(() => {
    const q = query(collection(db, 'properties'), where('ownerId', '==', user.uid))
    return onSnapshot(q, (snap) => {
      setProperties(snap.docs.map(d => ({ id: d.id, ...d.data() })))
    })
  }, [user.uid])

  useEffect(() => {
    const q = query(
      collection(db, 'inquiries'),
      where('landlordUid', '==', user.uid),
      orderBy('createdAt', 'desc')
    )
    return onSnapshot(q, (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() }))
      setInquiries(list)
      setChatInquiry(prev => {
        if (!prev) return prev
        const updated = list.find(i => i.id === prev.id)
        return updated || prev
      })
    })
  }, [user.uid])

  const totalCapacity = properties.reduce((s, p) => s + (Number(p.capacity) || 0), 0)
  const occupiedSlots = properties.reduce((s, p) => s + (p.tenants?.length || 0), 0)
  const set = (key) => (e) => setFormData(prev => ({ ...prev, [key]: e.target.value }))

  const handleAdd = async (e) => {
    e.preventDefault()
    setFormError('')
    if (!formData.location) { setFormError('Please pin the property location on the map.'); return }
    setSaving(true)
    try {
      await addDoc(collection(db, 'properties'), {
        ownerId: user.uid,
        title: formData.title,
        description: formData.description,
        price: Number(formData.price),
        capacity: Number(formData.capacity),
        rules: {
          curfewEnabled: formData.curfewEnabled,
          curfew: formData.curfewEnabled ? (formData.curfew || 'Set time') : 'No Curfew',
          genderRestriction: formData.genderRestriction
        },
        photos: formData.photos,
        location: formData.location,
        tenants: [],
        createdAt: serverTimestamp()
      })
      setFormData(EMPTY_FORM)
      setShowAddForm(false)
    } catch (err) {
      setFormError('Failed to save: ' + err.message)
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (propertyId) => {
    if (!window.confirm('Delete this property? This cannot be undone.')) return
    await deleteDoc(doc(db, 'properties', propertyId))
  }

  const handleProfilePhotoUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setPhotoUploading(true)
    try {
      const url = await uploadFile(ref(storage, `profiles/${user.uid}/photo_${Date.now()}`), file)
      setProfilePhoto(url)
      await updateUserProfile({ profilePhoto: url })
    } catch (err) {
      setProfileMsg('Photo upload failed: ' + err.message)
    } finally {
      setPhotoUploading(false)
    }
  }

  const handleSaveProfile = async () => {
    setProfileSaving(true)
    setProfileMsg('')
    try {
      await updateUserProfile({ fullName: profileName })
      setProfileMsg('Profile updated!')
      setTimeout(() => setProfileMsg(''), 3000)
    } catch (err) {
      setProfileMsg('Error: ' + err.message)
    } finally {
      setProfileSaving(false)
    }
  }

  const handleChangePassword = async () => {
    setPwMsg('')
    if (pwNew !== pwConfirm) { setPwMsg('New passwords do not match.'); return }
    if (pwNew.length < 6) { setPwMsg('Password must be at least 6 characters.'); return }
    try {
      await changePassword(pwCurrent, pwNew)
      setPwMsg('Password changed successfully!')
      setPwCurrent(''); setPwNew(''); setPwConfirm('')
      setTimeout(() => setPwMsg(''), 4000)
    } catch (err) {
      setPwMsg('Error: ' + err.message.replace('Firebase: ', '').replace(/\(auth\/.*\)\.?/, '').trim())
    }
  }

  const displayName = user.fullName || user.name || 'Owner'
  const TABS = [
    { id: 'overview', label: 'Overview' },
    { id: 'properties', label: 'Properties' },
    { id: 'analytics', label: 'Analytics' },
    { id: 'profile', label: 'My Profile' }
  ]

  return (
    <div className='max-w-7xl mx-auto px-6 py-8'>
      <div className='mb-8'>
        <h1 className='text-4xl font-bold text-slate-900'>Property Management</h1>
        <p className='text-slate-600 mt-2'>{displayName}</p>
      </div>

      {/* Tabs */}
      <div className='flex gap-2 mb-8 border-b border-slate-200 overflow-x-auto'>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-3 font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === tab.id ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── OVERVIEW ── */}
      {activeTab === 'overview' && (
        <div className='space-y-6'>
          <div className='grid grid-cols-2 md:grid-cols-4 gap-4'>
            {[
              { label: 'Properties', value: properties.length, color: 'text-indigo-600' },
              { label: 'Occupied', value: occupiedSlots, color: 'text-emerald-600' },
              { label: 'Available', value: totalCapacity - occupiedSlots, color: 'text-amber-600' },
              { label: 'Inquiries', value: inquiries.filter(i => i.status === 'pending').length, color: 'text-rose-600' }
            ].map(s => (
              <Card key={s.label}><CardContent>
                <div className='text-center'>
                  <div className={`text-3xl font-bold ${s.color} mb-1`}>{s.value}</div>
                  <p className='text-slate-600 text-sm'>{s.label}</p>
                </div>
              </CardContent></Card>
            ))}
          </div>

          {/* Inquiries */}
          <Card>
            <CardHeader><CardTitle>Tenant Inquiries</CardTitle></CardHeader>
            <CardContent>
              {inquiries.length === 0 ? (
                <p className='text-sm text-slate-500'>No inquiries yet.</p>
              ) : (
                <div className='space-y-3'>
                  {inquiries.map(inq => (
                    <div key={inq.id} className='p-4 bg-slate-50 rounded-xl border border-slate-100'>
                      <div className='flex items-start justify-between gap-2'>
                        <div className='min-w-0 flex-1'>
                          <div className='flex items-center gap-2'>
                            <p className='font-medium text-slate-900'>{inq.tenantName}</p>
                            {inq.unreadByOwner && (
                              <span className='w-2 h-2 rounded-full bg-indigo-600 shrink-0' title='New message' />
                            )}
                          </div>
                          <p className='text-xs text-slate-500'>{inq.tenantEmail}{inq.tenantPhone ? ` · ${inq.tenantPhone}` : ''}</p>
                          <p className='text-sm text-slate-700 mt-1'>
                            <span className='font-medium capitalize'>{inq.type === 'rent' ? 'Wants to rent' : 'Wants to visit'}</span>
                            {' — '}{inq.propertyTitle}
                          </p>
                          {inq.message && <p className='text-sm text-slate-600 mt-1 italic'>"{inq.message}"</p>}
                          {inq.lastMessage && inq.status === 'active' && (
                            <p className='text-xs text-slate-400 mt-1 truncate'>Last: {inq.lastMessage}</p>
                          )}
                        </div>
                        <div className='flex flex-col items-end gap-2 shrink-0'>
                          <Badge variant={inq.status === 'active' ? 'success' : 'warning'}>
                            {inq.status}
                          </Badge>
                          <button
                            type='button'
                            onClick={() => setChatInquiry(inq)}
                            className='text-sm text-indigo-600 font-medium hover:text-indigo-800 whitespace-nowrap'
                          >
                            {inq.status === 'pending' ? 'Reply →' : 'Open Chat →'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* ── PROPERTIES ── */}
      {activeTab === 'properties' && (
        <div className='space-y-6'>
          <div className='flex justify-end'>
            <Button variant={showAddForm ? 'secondary' : 'primary'}
              onClick={() => { setShowAddForm(v => !v); setFormError('') }}>
              {showAddForm ? 'Cancel' : '+ Add Property'}
            </Button>
          </div>

          {/* Add form */}
          {showAddForm && (
            <Card>
              <CardHeader><CardTitle>New Property</CardTitle></CardHeader>
              <CardContent>
                <form onSubmit={handleAdd} className='space-y-5'>
                  <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
                    <div className='md:col-span-2'>
                      <Label>Property Title</Label>
                      <Input placeholder='Sunrise Dorm' value={formData.title} onChange={set('title')} required />
                    </div>

                    <div className='md:col-span-2'>
                      <Label>Description</Label>
                      <textarea
                        value={formData.description}
                        onChange={set('description')}
                        rows={3}
                        placeholder='Describe your property, amenities, house rules...'
                        className='w-full px-4 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none'
                      />
                    </div>

                    <div>
                      <Label>Monthly Price (₱)</Label>
                      <Input type='number' min='0' placeholder='5000' value={formData.price} onChange={set('price')} required />
                    </div>

                    <div>
                      <Label>Capacity (max tenants)</Label>
                      <Input type='number' min='1' placeholder='4' value={formData.capacity} onChange={set('capacity')} required />
                    </div>

                    <div>
                      <Label>Curfew</Label>
                      <div className='mt-1'>
                        <Toggle
                          on={formData.curfewEnabled}
                          onToggle={() => setFormData(prev => ({ ...prev, curfewEnabled: !prev.curfewEnabled }))}
                          labelOn='Enabled' labelOff='No Curfew'
                        />
                        {formData.curfewEnabled && (
                          <Input className='mt-2' placeholder='e.g. 10:00 PM' value={formData.curfew} onChange={set('curfew')} />
                        )}
                      </div>
                    </div>

                    <div>
                      <Label>Gender Restriction</Label>
                      <select
                        value={formData.genderRestriction} onChange={set('genderRestriction')}
                        className='w-full mt-1 px-4 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500'
                      >
                        <option value='none'>No Restriction</option>
                        <option value='male'>Male Only</option>
                        <option value='female'>Female Only</option>
                      </select>
                    </div>

                    <div className='md:col-span-2'>
                      <Label>Property Photos</Label>
                      <ImageUploader
                        value={formData.photos}
                        onChange={(photos) => setFormData(prev => ({ ...prev, photos }))}
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Property Location</Label>
                    <p className='text-xs text-slate-500 mb-2'>Search or click the map to pin the location.</p>
                    <LocationPicker
                      value={formData.location}
                      onChange={(loc) => setFormData(prev => ({ ...prev, location: loc }))}
                    />
                  </div>

                  {formError && <p className='text-sm text-red-600 bg-red-50 border border-red-200 p-3 rounded-lg'>{formError}</p>}

                  <Button type='submit' variant='primary' disabled={saving}>
                    {saving ? 'Saving...' : 'Add Property'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}

          {properties.length === 0 && !showAddForm && (
            <Card><CardContent>
              <div className='text-center py-12'>
                <p className='text-lg text-slate-600'>No properties yet.</p>
                <p className='text-sm text-slate-500 mt-1'>Click "Add Property" to get started.</p>
              </div>
            </CardContent></Card>
          )}

          {properties.map(property => (
            <Card key={property.id}>
              <CardHeader>
                <div className='flex items-start justify-between gap-3'>
                  <div>
                    <CardTitle>{property.title}</CardTitle>
                    <p className='text-sm text-slate-500 mt-1'>{property.location?.address || 'No location pinned'}</p>
                  </div>
                  <div className='flex items-center gap-2 shrink-0'>
                    <Badge variant='primary'>₱{Number(property.price).toLocaleString()}/mo</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {property.description && (
                  <p className='text-sm text-slate-600 mb-4'>{property.description}</p>
                )}
                {property.photos?.length > 0 && (
                  <div className='grid grid-cols-3 gap-2 mb-4'>
                    {property.photos.map((url, i) => (
                      <img key={i} src={url} alt='' className='w-full h-28 object-cover rounded-lg' onError={e => { e.target.style.display='none' }} />
                    ))}
                  </div>
                )}
                <div className='grid grid-cols-2 md:grid-cols-4 gap-3 mb-4'>
                  {[
                    { label: 'Capacity', value: property.capacity },
                    { label: 'Tenants', value: `${property.tenants?.length || 0}/${property.capacity}` },
                    { label: 'Curfew', value: property.rules?.curfew || 'No Curfew' },
                    { label: 'Gender', value: property.rules?.genderRestriction === 'none' ? 'Open' : property.rules?.genderRestriction }
                  ].map(s => (
                    <div key={s.label}>
                      <p className='text-xs text-slate-500 font-medium'>{s.label}</p>
                      <p className='text-lg font-bold text-slate-900 capitalize'>{s.value}</p>
                    </div>
                  ))}
                </div>
                <div className='flex gap-2'>
                  <Button size='sm' variant='primary' onClick={() => setEditingProperty(property)}>
                    Edit
                  </Button>
                  <Button size='sm' variant='danger' onClick={() => handleDelete(property.id)}>
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* ── ANALYTICS ── */}
      {activeTab === 'analytics' && (
        <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
          <Card>
            <CardHeader><CardTitle>Revenue (Est.)</CardTitle></CardHeader>
            <CardContent>
              <p className='text-sm text-slate-600'>This Month</p>
              <p className='text-3xl font-bold text-slate-900'>
                ₱{properties.reduce((s, p) => s + (Number(p.price)||0)*(p.tenants?.length||0), 0).toLocaleString()}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Occupancy</CardTitle></CardHeader>
            <CardContent>
              <div className='w-full bg-slate-200 rounded-full h-2'>
                <div className='bg-indigo-600 h-2 rounded-full' style={{ width: `${totalCapacity > 0 ? (occupiedSlots/totalCapacity)*100 : 0}%` }} />
              </div>
              <p className='text-sm text-slate-600 mt-2'>{occupiedSlots}/{totalCapacity} slots occupied</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* ── PROFILE ── */}
      {activeTab === 'profile' && (
        <div className='max-w-xl space-y-6'>
          {/* Avatar */}
          <Card>
            <CardHeader><CardTitle>Profile Photo</CardTitle></CardHeader>
            <CardContent>
              <div className='flex items-center gap-6'>
                <div className='w-20 h-20 rounded-full overflow-hidden bg-indigo-100 border-2 border-indigo-200 shrink-0'>
                  {profilePhoto
                    ? <img src={profilePhoto} alt='Profile' className='w-full h-full object-cover' />
                    : <div className='w-full h-full flex items-center justify-center text-2xl font-bold text-indigo-600'>
                        {displayName.charAt(0).toUpperCase()}
                      </div>
                  }
                </div>
                <div>
                  <label className='cursor-pointer'>
                    <span className='px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors'>
                      {photoUploading ? 'Uploading...' : 'Upload Photo'}
                    </span>
                    <input type='file' accept='image/*' className='hidden' onChange={handleProfilePhotoUpload} disabled={photoUploading} />
                  </label>
                  <p className='text-xs text-slate-500 mt-2'>JPG, PNG — max 5 MB</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Name */}
          <Card>
            <CardHeader><CardTitle>Account Info</CardTitle></CardHeader>
            <CardContent className='space-y-4'>
              <div>
                <Label>Full Name</Label>
                <Input value={profileName} onChange={e => setProfileName(e.target.value)} />
              </div>
              <div>
                <Label>Email</Label>
                <Input value={user.email} disabled className='opacity-60 cursor-not-allowed' />
              </div>
              {profileMsg && <p className='text-sm text-emerald-600'>{profileMsg}</p>}
              <Button onClick={handleSaveProfile} variant='primary' disabled={profileSaving}>
                {profileSaving ? 'Saving...' : 'Save Changes'}
              </Button>
            </CardContent>
          </Card>

          {/* Change password */}
          <Card>
            <CardHeader><CardTitle>Change Password</CardTitle></CardHeader>
            <CardContent className='space-y-3'>
              <div>
                <Label>Current Password</Label>
                <Input type='password' value={pwCurrent} onChange={e => setPwCurrent(e.target.value)} placeholder='Enter current password' />
              </div>
              <div>
                <Label>New Password</Label>
                <Input type='password' value={pwNew} onChange={e => setPwNew(e.target.value)} placeholder='At least 6 characters' />
              </div>
              <div>
                <Label>Confirm New Password</Label>
                <Input type='password' value={pwConfirm} onChange={e => setPwConfirm(e.target.value)} placeholder='Repeat new password' />
              </div>
              {pwMsg && <p className={`text-sm ${pwMsg.startsWith('Error') ? 'text-red-600' : 'text-emerald-600'}`}>{pwMsg}</p>}
              <Button onClick={handleChangePassword} variant='primary'>Update Password</Button>
            </CardContent>
          </Card>

          {/* Logout */}
          <Card>
            <CardContent>
              <Button onClick={logout} variant='danger' className='w-full'>Sign Out</Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Edit modal */}
      {editingProperty && (
        <EditPropertyModal
          property={editingProperty}
          onClose={() => setEditingProperty(null)}
        />
      )}

      {/* Chat modal */}
      {chatInquiry && (
        <ChatModal
          inquiry={chatInquiry}
          currentUser={user}
          onClose={() => setChatInquiry(null)}
        />
      )}
    </div>
  )
}
