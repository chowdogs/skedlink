import React from 'react'
import { Button } from '../ui/Button'

export const MainLayout = ({ children, onLogout, currentUser }) => {
  return (
    <div className='min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100'>
      <header className='border-b border-slate-200 bg-white shadow-sm'>
        <div className='max-w-7xl mx-auto px-6 py-4 flex items-center justify-between'>
          <div className='flex items-center gap-3'>
            <div className='w-10 h-10 bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-lg flex items-center justify-center'>
              <span className='text-white font-bold text-lg'>S</span>
            </div>
            <h1 className='text-2xl font-bold text-slate-900'>SkedLink</h1>
          </div>
          
          <div className='flex items-center gap-4'>
            {currentUser && (
              <div className='flex items-center gap-3'>
                <span className='text-sm text-slate-700'>Hi, {(currentUser.fullName || currentUser.name || 'User').split(' ')[0]}</span>
                <Button onClick={onLogout} variant='secondary' size='sm'>
                  Logout
                </Button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className='flex-1'>
        {children}
      </main>

      <footer className='border-t border-slate-200 bg-white py-6 mt-12'>
        <div className='max-w-7xl mx-auto px-6 text-center text-sm text-slate-600'>
          <p>© 2024 SkedLink. Revolutionizing dormitory living through lifestyle compatibility.</p>
        </div>
      </footer>
    </div>
  )
}
