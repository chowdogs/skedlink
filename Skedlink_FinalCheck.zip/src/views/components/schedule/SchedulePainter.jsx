import React, { useState } from 'react'
import { DAYS, CUSTOM_PALETTE } from '../../../controllers/useSchedulePainter'

const DAY_LABELS = { monday:'Mon', tuesday:'Tue', wednesday:'Wed', thursday:'Thu', friday:'Fri', saturday:'Sat', sunday:'Sun' }
const HOURS = Array.from({ length: 24 }, (_, i) => i)

export const SchedulePainter = ({
  schedule, onHourChange, currentActivity, onActivityChange,
  allActivities, getActivityHex,
  onAddCustomActivity, onRemoveCustomActivity, customActivities
}) => {
  const [showAddForm, setShowAddForm] = useState(false)
  const [newLabel, setNewLabel] = useState('')
  const [newColor, setNewColor] = useState(CUSTOM_PALETTE[0])

  const handleAddActivity = async () => {
    if (!newLabel.trim()) return
    await onAddCustomActivity(newLabel.trim(), newColor)
    setNewLabel('')
    setNewColor(CUSTOM_PALETTE[0])
    setShowAddForm(false)
  }

  return (
    <div className='space-y-6'>
      {/* Activity Legend */}
      <div>
        <h3 className='text-lg font-semibold text-slate-900 mb-3'>Activity</h3>
        <div className='flex flex-wrap gap-2'>
          {allActivities.map(act => (
            <div key={act.id} className='flex items-center gap-1'>
              <button
                type='button'
                onClick={() => onActivityChange(act.id)}
                style={{
                  backgroundColor: act.hex,
                  opacity: currentActivity === act.id ? 1 : 0.5,
                  transform: currentActivity === act.id ? 'scale(1.05)' : 'scale(1)',
                  boxShadow: currentActivity === act.id ? '0 4px 12px rgba(0,0,0,0.2)' : 'none'
                }}
                className='px-3 py-1.5 rounded-lg text-white text-sm font-medium transition-all'
              >
                {act.label}
              </button>
              {customActivities?.some(c => c.id === act.id) && (
                <button
                  type='button'
                  onClick={() => onRemoveCustomActivity(act.id)}
                  className='w-4 h-4 rounded-full bg-slate-200 hover:bg-red-400 text-slate-600 hover:text-white text-xs flex items-center justify-center transition-colors'
                  title='Remove activity'
                >
                  ×
                </button>
              )}
            </div>
          ))}

          {/* Add custom activity */}
          <button
            type='button'
            onClick={() => setShowAddForm(v => !v)}
            className='px-3 py-1.5 rounded-lg border-2 border-dashed border-slate-300 text-slate-500 text-sm font-medium hover:border-indigo-400 hover:text-indigo-600 transition-colors'
          >
            + Add Activity
          </button>
        </div>

        {/* Custom activity form */}
        {showAddForm && (
          <div className='mt-3 p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap gap-3 items-end'>
            <div>
              <label className='text-xs font-medium text-slate-600 block mb-1'>Activity Name</label>
              <input
                type='text'
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddActivity()}
                placeholder='e.g. Eating, Gym...'
                className='px-3 py-1.5 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500'
              />
            </div>
            <div>
              <label className='text-xs font-medium text-slate-600 block mb-1'>Color</label>
              <div className='flex gap-1'>
                {CUSTOM_PALETTE.map(hex => (
                  <button
                    key={hex}
                    type='button'
                    onClick={() => setNewColor(hex)}
                    style={{ backgroundColor: hex }}
                    className={`w-6 h-6 rounded-full transition-transform ${newColor === hex ? 'scale-125 ring-2 ring-offset-1 ring-slate-400' : ''}`}
                  />
                ))}
              </div>
            </div>
            <div className='flex gap-2'>
              <button
                type='button'
                onClick={handleAddActivity}
                style={{ backgroundColor: newColor }}
                className='px-4 py-1.5 rounded-lg text-white text-sm font-medium'
              >
                Add
              </button>
              <button
                type='button'
                onClick={() => setShowAddForm(false)}
                className='px-4 py-1.5 rounded-lg bg-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-300'
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 7-day × 24-hour Grid */}
      <div>
        <h3 className='text-lg font-semibold text-slate-900 mb-3'>Weekly Schedule</h3>
        <p className='text-xs text-slate-500 mb-2'>Select an activity above, then click or drag to paint.</p>
        <div className='overflow-x-auto'>
          <div className='min-w-max'>
            {/* Hour header */}
            <div className='flex mb-1'>
              <div className='w-10 shrink-0' />
              {HOURS.map(h => (
                <div key={h} className='w-7 text-center text-xs text-slate-400 font-mono leading-none'>
                  {h % 6 === 0 ? String(h).padStart(2, '0') : ''}
                </div>
              ))}
            </div>
            {/* Day rows */}
            {DAYS.map(day => (
              <div key={day} className='flex items-center mb-0.5'>
                <div className='w-10 shrink-0 text-xs font-semibold text-slate-600 pr-1 text-right'>
                  {DAY_LABELS[day]}
                </div>
                {HOURS.map(h => {
                  const actId = schedule?.[day]?.[h] || 'dayoff'
                  const hex = getActivityHex(actId)
                  return (
                    <button
                      key={h}
                      type='button'
                      onClick={() => onHourChange(day, h, currentActivity)}
                      onMouseEnter={(e) => { if (e.buttons === 1) onHourChange(day, h, currentActivity) }}
                      style={{ backgroundColor: hex }}
                      className='w-7 h-7 rounded-sm transition-opacity hover:opacity-75 active:scale-95'
                      title={`${DAY_LABELS[day]} ${String(h).padStart(2,'0')}:00`}
                    />
                  )
                })}
              </div>
            ))}
          </div>
        </div>
        <div className='mt-2 grid grid-cols-4 gap-2 text-xs text-slate-400 pl-10'>
          <span>00:00 — Midnight</span>
          <span>06:00 — Morning</span>
          <span>12:00 — Noon</span>
          <span>18:00 — Evening</span>
        </div>
      </div>

      {/* Weekly Summary */}
      <div>
        <h3 className='text-lg font-semibold text-slate-900 mb-3'>Weekly Summary</h3>
        <div className='grid grid-cols-2 md:grid-cols-3 gap-3'>
          {allActivities.map(act => {
            let count = 0
            DAYS.forEach(day => {
              Object.values(schedule?.[day] || {}).forEach(a => { if (a === act.id) count++ })
            })
            return (
              <div key={act.id} className='bg-slate-50 p-3 rounded-lg flex items-center gap-2'>
                <div className='w-3 h-3 rounded-full shrink-0' style={{ backgroundColor: act.hex }} />
                <span className='text-sm font-medium text-slate-800 truncate'>{act.label}:</span>
                <span className='text-sm text-slate-500 ml-auto'>{count}h</span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
