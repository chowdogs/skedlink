import React from 'react'

export const Badge = ({ children, variant = 'primary', className }) => {
  const variants = {
    primary: 'bg-indigo-100 text-indigo-700',
    success: 'bg-emerald-100 text-emerald-700',
    warning: 'bg-amber-100 text-amber-700',
    danger: 'bg-red-100 text-red-700',
    slate: 'bg-slate-100 text-slate-700'
  }

  return (
    <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${variants[variant]} ${className || ''}`}>
      {children}
    </span>
  )
}
