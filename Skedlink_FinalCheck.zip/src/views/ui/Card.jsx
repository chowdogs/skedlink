import React from 'react'

export const Card = React.forwardRef(({ children, className }, ref) => (
  <div
    ref={ref}
    className={`bg-white rounded-xl shadow-sm border border-slate-200 p-6 ${className || ''}`}
  >
    {children}
  </div>
))

Card.displayName = 'Card'

export const CardHeader = ({ children, className }) => (
  <div className={`mb-4 ${className || ''}`}>
    {children}
  </div>
)

export const CardTitle = ({ children, className }) => (
  <h2 className={`text-xl font-semibold text-slate-900 ${className || ''}`}>
    {children}
  </h2>
)

export const CardDescription = ({ children, className }) => (
  <p className={`text-sm text-slate-600 mt-1 ${className || ''}`}>
    {children}
  </p>
)

export const CardContent = ({ children, className }) => (
  <div className={className || ''}>
    {children}
  </div>
)

export const CardFooter = ({ children, className }) => (
  <div className={`mt-6 pt-6 border-t border-slate-200 flex gap-3 ${className || ''}`}>
    {children}
  </div>
)
